import React from 'react'

function Navbar() {
  return (
    <>
      <div className='flex bg-gray-800 text-white'>
        <div>Home</div>
        <div>About us</div>
        <div>Contact</div>  
      </div>  
    </>
  )
}

export default Navbar